[ "$(uname)" = "$1" ] && echo y || echo n
